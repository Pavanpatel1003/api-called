// $("button").click(function(){
//         debugger
//         $("#clickme").load("data.json",function(responseTxt, statusTxt, xhr){
//             if(statusTxt == "success")
//             var data = JSON.parse(responseTxt);
//             debugger
//             $("#Firstname").append(data.FirstName);
//             $("#City").append(data.City);
//             $("#Pincode").append(data.Pincode);
//             $("#Country").append(data.Country);
//             $("#Religion").append(data.Religion);

//             console.log("External content loaded successfully!");
//           if(statusTxt == "error")
//             console.log("Error: " + xhr.status + ": " + xhr.statusText);
//         })


//     })
var text = "";
text1 = '';

window.addEventListener('load', (event) => {
  debugger
  console.log('page is fully loaded');
});
$(document).ready(function () {

  
  $.get("https://services.sportfolio.co.uk/api/get-all-sports",function (data, status) {

    codeFormater(data);
  });
});


function codeFormater(data) {
  text1 = '';

      for (let index = 0; index < data.data.length; index++) {
        text += " <div class='col-3'> " + "Name:" + data.data[index].name + "<br>" + "Id:"  + data.data[index].id + "<br>" + "Status:"  + data.data[index].status + "</div>"
        text1 +=  "<div class='col-4 mb-4'><div class='bg-red bg-warning' style='    height: 100%;border: 2px solid;border-radius: 14px;text-align: center;'><h1>" + data.data[index].name + " </h1><p>"  + data.data[index].status + "</p><p>"  + data.data[index].id + "</p></div></div>"
    
      }

      var total = "<div class='container'>" + "<div class='row'>"+text + "</div>" +"</div>"
      // $('#clickit').html(total);
      printcode()
}


function printcode() {
$('.loader').hide();
  $('#clickit1').html(text1);
}


// https://services.sportfolio.co.uk/api/get-all-university
// sport_id: 13
// region: 2